# Roleplay Vault (Android project)

An offline, fictional crypto-wallet-style interface for LARP / roleplay. It is inspired by the general dark-blue wallet-app layout, but does not use Trust Wallet branding or impersonate its service.

## Included
- Editable simulated USD balance
- Add fictional assets and set their displayed values
- Mock send / receive entries that update only the local demo balance
- Local transaction history saved on the device
- Persistent `SIMULATION` labels; no blockchain, payment rails, wallet keys, addresses, or real transfers

## Build the APK
1. Install Android Studio (current stable) with Android SDK Platform 35.
2. Open this `RoleplayVault` folder in Android Studio.
3. Let Gradle sync and install any requested Android components.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).

The APK is not prebuilt in this package because the build environment used to prepare these files does not include the Android SDK.
