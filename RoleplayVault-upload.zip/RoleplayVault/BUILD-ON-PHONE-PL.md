# Jak zbudować APK z telefonu (GitHub Actions)

1. Załóż lub zaloguj się na konto GitHub.
2. Utwórz nowe, prywatne repozytorium (New repository).
3. Wgraj do repozytorium plik `RoleplayVault-Android-Project.zip`.
4. Dodaj plik `.github/workflows/build-apk.yml` z zawartością pliku o tej samej nazwie z paczki (Add file → Create new file).
5. Otwórz zakładkę Actions, wybierz „Build RoleplayVault APK”, kliknij „Run workflow”.
6. Po zakończeniu otwórz uruchomiony workflow i pobierz artefakt `RoleplayVault-debug-apk`.
7. Rozpakuj pobrany artefakt ZIP — w środku będzie `app-debug.apk`.

Ważne: repozytorium ustaw jako prywatne. APK jest wyłącznie symulacją do roleplay; nie obsługuje prawdziwych kryptowalut ani płatności.
